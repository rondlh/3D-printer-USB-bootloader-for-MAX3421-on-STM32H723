:hide-toc:

.. include:: ../README_processed.rst

.. toctree::
   :caption: Index
   :hidden:

   Info <info/index>
   Reference <reference/index>
   Contributing <contributing/index>

.. toctree::
   :caption: External Links
   :hidden:

   Source Code <https://github.com/hathach/tinyusb>
   Issue Tracker <https://github.com/hathach/tinyusb/issues>
   Discussions <https://github.com/hathach/tinyusb/discussions>
